from django.shortcuts import render

def index(request):
    return render(request,"guest/index.html")

def about(request):
    return render(request,"guest/about.html")